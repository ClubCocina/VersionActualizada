<div id="pasos" class="menu overflowauto">
        <ul class="centerbox overflowauto">
            <li>Confirma los detalles de tu evento</li>
            <li>Ubicaci&oacute;n del evento</li>
            <li>Realizar pago</li>
            <li>Comprobante</li>
        </ul>
</div>