<div id="wrapper-form">
    <?php $this->load->view('form_registro'); ?>
</div>