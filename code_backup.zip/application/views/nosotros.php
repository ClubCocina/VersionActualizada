<div id="content-nosotros">
    <div id="texto-nosotros">
        <div><?= $pagina['bajada']; ?></div>
        <div><?= $pagina['contenido']?></div>
    </div>
</div>