</div> <!-- content -->
</div> <!-- wrapper-content -->
<div id="wrapper-footer">
<div id="footer">® radar.cl 2004-2013 - Todos los derechos reservados</div>
</div>
</body>
</html>