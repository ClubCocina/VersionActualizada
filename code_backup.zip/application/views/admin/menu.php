<li><a href="<?= base_url('admin/usuarios/'); ?>" >Usuarios</a></li>
<li class="has-dropdown">
    <a href="<?= base_url('admin/chefs/listarUsuarios/2'); ?>" >Chefs</a> 
    <ul class="dropdown">
        <li><a href="<?= base_url('admin/metas/listarMetasChef'); ?>">Atributos Chef</a></li>
        <li><a href="<?= base_url('admin/metas/listarMetasCalificacion'); ?>">Atributos de Calificaci&oacute;n</a></li>
    </ul>
</li>
<li><a href="<?= base_url('admin/actividades/listaActividades'); ?>">Eventos</a></li>
<li><a href="<?= base_url('admin/periodos'); ?>">Periodos Chef</a></li>
<li><a href="<?= base_url('admin/pages'); ?>">Paginas</a></li>

