</div> <!-- content -->
</div> <!-- wrapper-content -->

<div id="wrapper-footer-admin">
<div id="footer">
    <div class="row">
        <div class="large-12 columns">
    Club de la Cocina - Todos los derechos reservados
        </div>
    </div>
</div>
</div>
<script src="<?=base_url()?>js/vendor/jquery.js"></script>
  <script src="<?=base_url()?>js/foundation.min.js"></script>
  <script src="<?=base_url()?>js/jquery.quick.pagination.min.js"></script>
  <script>
    $(document).foundation();
    $("ul.lista-ver").quickPagination();
  </script>
</body>
</html>