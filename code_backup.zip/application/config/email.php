<?php

$config = array(
    'smtp_host' => 'mail.clubdelacocina.cl',
    'smtp_user' => 'contacto@clubdelacocina.cl',
    'smtp_pass' => 'club852..',
    'protocol' => 'smtp'
);